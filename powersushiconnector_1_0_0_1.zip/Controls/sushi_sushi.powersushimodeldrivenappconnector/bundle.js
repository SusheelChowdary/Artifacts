/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./powersushimodeldrivenappconnector/index.ts":
/*!****************************************************!*\
  !*** ./powersushimodeldrivenappconnector/index.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   powersushimodeldrivenappconnector: () => (/* binding */ powersushimodeldrivenappconnector)\n/* harmony export */ });\nclass powersushimodeldrivenappconnector {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {}\n  init(context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n  }\n  updateView(context) {\n    // Add code to update control view\n    var inputValue = context.parameters.inputDataJson.raw;\n    if (inputValue !== null && inputValue !== undefined && inputValue !== \"\") {\n      this.triggerCustomEvent(inputValue);\n    }\n  }\n  triggerCustomEvent(inputValue) {\n    var customEvent = new CustomEvent(\"powerSushiConnectorEvent\", {\n      detail: {\n        message: inputValue\n      }\n    });\n    // Dispatch the custom event\n    window.dispatchEvent(customEvent);\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./powersushimodeldrivenappconnector/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./powersushimodeldrivenappconnector/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('sushi.powersushimodeldrivenappconnector', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.powersushimodeldrivenappconnector);
} else {
	var sushi = sushi || {};
	sushi.powersushimodeldrivenappconnector = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.powersushimodeldrivenappconnector;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}